import { Router } from "express";
import {
  getSettings,
  updateSettings,
  updateBranding,
  updateContactInfo,
  updateHeroSlides,
  updateHeroBanners,
  updateCardHeroSlides,
  updateTrustBadges,
  updateAboutUs,
  updateContactPage,
  updatePrivacy,
  updateTerms,
  updateNotifications,
  getSmsSettings,
  updateSmsSettings,
  sendTestSms,
} from "../controllers/settings.controller";
import {
  protect,
  adminOnly,
  optionalAuth,
} from "../middlewares/auth.middleware";

const router = Router();

router.get("/", optionalAuth, getSettings);
router.put("/", protect, adminOnly, updateSettings);
router.put("/branding", protect, adminOnly, updateBranding);
router.put("/contact", protect, adminOnly, updateContactInfo);
router.put("/hero-slides", protect, adminOnly, updateHeroSlides);
router.put("/hero-banners", protect, adminOnly, updateHeroBanners);
router.put("/card-hero-slides", protect, adminOnly, updateCardHeroSlides);
router.put("/trust-badges", protect, adminOnly, updateTrustBadges);

// NEW ROUTES
router.put("/about-us", protect, adminOnly, updateAboutUs);
router.put("/contact-page", protect, adminOnly, updateContactPage);

router.put("/privacy", protect, adminOnly, updatePrivacy);
router.put("/terms", protect, adminOnly, updateTerms);
router.put("/notifications", protect, adminOnly, updateNotifications);

// SMS provider settings (Termii, etc.) — feeds the bulk-SMS marketing feature
router.get("/sms", protect, adminOnly, getSmsSettings);
router.put("/sms", protect, adminOnly, updateSmsSettings);
router.post("/sms/test", protect, adminOnly, sendTestSms);

export default router;
