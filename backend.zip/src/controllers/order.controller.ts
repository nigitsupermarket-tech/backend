import { Request, Response, NextFunction } from "express";
import prisma from "../config/database";
import { AppError, NotFoundError } from "../utils/appError";
import { AuthRequest } from "../middlewares/auth.middleware";
import { log as logActivity } from "../utils/activityLogger";
import {
  sendOrderConfirmationEmail,
  sendTrackingUpdateEmail,
  sendAdminNewOrderEmail,
} from "../services/email.service";
import { restoreStockForOrder } from "../lib/orderStock";
import {
  findActiveVariation,
  resolveVariationLine,
  assertVariationStock,
} from "../lib/productVariation";

const generateOrderNumber = () =>
  `ORD-${Date.now().toString().slice(-8)}-${Math.floor(Math.random() * 1000)
    .toString()
    .padStart(3, "0")}`;

// ── Email automation mode lookup (Settings → Notifications) ──────────────────
// Both default to "manual" (see SiteSetting schema) — an auto-send only
// happens once a super admin explicitly flips it on.
async function getEmailAutomationModes(): Promise<{
  invoiceEmailMode: "manual" | "auto";
  orderStatusEmailMode: "manual" | "auto";
}> {
  const settings = await prisma.siteSetting.findFirst({
    select: { invoiceEmailMode: true, orderStatusEmailMode: true },
  });
  return {
    invoiceEmailMode:
      (settings?.invoiceEmailMode as "manual" | "auto") || "manual",
    orderStatusEmailMode:
      (settings?.orderStatusEmailMode as "manual" | "auto") || "manual",
  };
}

// Sends the order-confirmation/invoice email if it hasn't gone out yet.
// Called both right after order creation and (defensively) from payment
// confirmation — the invoiceEmailSent flag guarantees it only ever sends once.
export async function maybeSendInvoiceEmail(orderId: string): Promise<void> {
  const order = await prisma.order.findUnique({ where: { id: orderId } });
  if (!order || order.invoiceEmailSent) return;

  const { invoiceEmailMode } = await getEmailAutomationModes();
  if (invoiceEmailMode !== "auto") return; // manual — staff sends via "Send Invoice"

  await sendOrderConfirmationEmail(
    order.customerEmail,
    order.customerName,
    order.orderNumber,
    order.total,
  );
  await prisma.order.update({
    where: { id: orderId },
    data: { invoiceEmailSent: true },
  });
}

// GET /api/v1/orders
export const getOrders = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction,
) => {
  try {
    const {
      page = "1",
      limit = "10",
      status,
      paymentStatus,
      search,
      startDate,
      endDate,
    } = req.query;
    const skip = (Number(page) - 1) * Number(limit);
    // Any staff-side role (everything except CUSTOMER) can see all orders.
    const isAdmin = req.user?.role !== "CUSTOMER";

    const where: any = {};
    if (!isAdmin) where.userId = req.user?.userId;
    if (status) where.status = status;
    if (paymentStatus) where.paymentStatus = paymentStatus;
    if (search) {
      where.OR = [
        { orderNumber: { contains: search as string, mode: "insensitive" } },
        { customerEmail: { contains: search as string, mode: "insensitive" } },
        { customerName: { contains: search as string, mode: "insensitive" } },
      ];
    }
    if (startDate || endDate) {
      where.createdAt = {};
      if (startDate) where.createdAt.gte = new Date(startDate as string);
      if (endDate) where.createdAt.lte = new Date(endDate as string);
    }

    const [orders, total] = await Promise.all([
      prisma.order.findMany({
        where,
        skip,
        take: Number(limit),
        orderBy: { createdAt: "desc" },
        include: {
          items: {
            include: {
              product: { select: { id: true, name: true, images: true } },
            },
          },
          user: { select: { id: true, name: true, email: true } },
        },
      }),
      prisma.order.count({ where }),
    ]);

    res.status(200).json({
      success: true,
      data: {
        orders,
        pagination: {
          page: Number(page),
          limit: Number(limit),
          total,
          totalPages: Math.ceil(total / Number(limit)),
          hasMore: skip + orders.length < total,
        },
      },
    });
  } catch (error) {
    next(error);
  }
};

// GET /api/v1/orders/:id
export const getOrder = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction,
) => {
  try {
    const id = req.params.id as string; // ✅ fix: lines 68 (id & orderNumber)
    // Any staff-side role (everything except CUSTOMER) can see all orders.
    const isAdmin = req.user?.role !== "CUSTOMER";

    const order = await prisma.order.findFirst({
      where: { OR: [{ id }, { orderNumber: id }] },
      include: {
        items: { include: { product: true } },
        user: { select: { id: true, name: true, email: true, phone: true } },
        // ✅ fix: removed `discount: true` — no such relation on Order; discountId is a scalar field
        statusHistory: { orderBy: { createdAt: "asc" } },
      },
    });

    if (!order) throw new NotFoundError("Order not found");
    if (!isAdmin && order.userId !== req.user?.userId)
      throw new AppError("Not authorized", 403);

    res.status(200).json({ success: true, data: { order } });
  } catch (error) {
    next(error);
  }
};

// PUT /api/v1/orders/:id/status
export const updateOrderStatus = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction,
) => {
  try {
    const id = req.params.id as string; // ✅ fix: lines 248, 260, 261, 266

    const { status, notes, trackingNumber, estimatedDelivery } = req.body;

    const order = await prisma.order.findUnique({ where: { id } });
    if (!order) throw new NotFoundError("Order not found");

    const updates: any = { status };
    if (trackingNumber) updates.trackingNumber = trackingNumber;
    if (estimatedDelivery)
      updates.estimatedDelivery = new Date(estimatedDelivery);
    if (status === "CONFIRMED") updates.confirmedAt = new Date();
    if (status === "SHIPPED") updates.shippedAt = new Date();
    if (status === "DELIVERED") updates.deliveredAt = new Date();
    if (status === "CANCELLED") updates.cancelledAt = new Date();

    const [updated] = await prisma.$transaction([
      prisma.order.update({ where: { id }, data: updates }),
      prisma.orderStatusHistory.create({
        data: { orderId: id, status, notes },
      }),
    ]);

    if (status === "CANCELLED") {
      // Only restores stock if it was actually deducted (i.e. payment had
      // been confirmed) — orders cancelled before payment never touched
      // inventory, so there's nothing to give back.
      await restoreStockForOrder(
        id,
        "Order cancelled by staff",
        req.user?.userId
          ? { id: req.user.userId, name: req.user.email }
          : undefined,
      );
    }

    // Customer status-change notification — respects Settings →
    // Notifications → "Order status email" mode (manual by default; staff
    // sends it via the "Notify Customer" button unless a super admin turns
    // auto on).
    const { orderStatusEmailMode } = await getEmailAutomationModes();
    if (orderStatusEmailMode === "auto") {
      sendTrackingUpdateEmail(
        order.customerEmail,
        order.customerName,
        order.orderNumber,
        status,
        notes || `Your order status has been updated to ${status}.`,
      )
        .then(() =>
          prisma.order.update({
            where: { id },
            data: { lastStatusEmailAt: new Date() },
          }),
        )
        .catch((err) =>
          console.error("[email] Status update email failed:", err),
        );
    }

    logActivity({
      userId: req.user?.userId,
      action: `update order status → ${status}`,
      entity: "order",
      entityId: id,
      metadata: {
        orderNumber: order.orderNumber,
        previousStatus: order.status,
        newStatus: status,
        notes,
      },
      req,
    });

    res.status(200).json({
      success: true,
      message: "Order status updated",
      data: { order: updated },
    });
  } catch (error) {
    next(error);
  }
};

// PUT /api/v1/orders/:id/cancel
export const cancelOrder = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction,
) => {
  try {
    const id = req.params.id as string; // ✅ fix: lines 286, 296, 297, 301

    // ✅ fix: include items so order.items is available below (line 301)
    const order = await prisma.order.findUnique({
      where: { id },
      include: { items: true },
    });
    if (!order) throw new NotFoundError("Order not found");
    if (order.userId !== req.user?.userId)
      throw new AppError("Not authorized", 403);

    const cancellableStatuses = ["PENDING", "CONFIRMED"];
    if (!cancellableStatuses.includes(order.status)) {
      throw new AppError("Order cannot be cancelled at this stage", 400);
    }

    await prisma.$transaction([
      prisma.order.update({
        where: { id },
        data: { status: "CANCELLED", cancelledAt: new Date() },
      }),
      prisma.orderStatusHistory.create({
        data: {
          orderId: id,
          status: "CANCELLED",
          notes: "Cancelled by customer",
        },
      }),
    ]);

    // Only restores stock if it was actually deducted (i.e. payment had
    // been confirmed) — guarded internally by Order.stockDeducted.
    await restoreStockForOrder(id, "Order cancelled by customer");

    res
      .status(200)
      .json({ success: true, message: "Order cancelled successfully" });
  } catch (error) {
    next(error);
  }
};

// GET /api/v1/orders/stats
export const getOrderStats = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction,
) => {
  try {
    const today = new Date();
    const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
    const startOfLastMonth = new Date(
      today.getFullYear(),
      today.getMonth() - 1,
      1,
    );
    const endOfLastMonth = new Date(today.getFullYear(), today.getMonth(), 0);

    const [
      totalOrders,
      monthOrders,
      lastMonthOrders,
      revenueData,
      statusCounts,
    ] = await Promise.all([
      prisma.order.count({ where: { paymentStatus: "PAID" } }),
      prisma.order.aggregate({
        where: { createdAt: { gte: startOfMonth }, paymentStatus: "PAID" },
        _sum: { total: true },
        _count: true,
      }),
      prisma.order.aggregate({
        where: {
          createdAt: { gte: startOfLastMonth, lte: endOfLastMonth },
          paymentStatus: "PAID",
        },
        _sum: { total: true },
        _count: true,
      }),
      prisma.order.groupBy({ by: ["status"], _count: true }),
      prisma.order.groupBy({ by: ["status"], _count: true }),
    ]);

    res.status(200).json({
      success: true,
      data: {
        totalOrders,
        monthRevenue: monthOrders._sum.total || 0,
        monthOrders: monthOrders._count,
        lastMonthRevenue: lastMonthOrders._sum.total || 0,
        statusBreakdown: revenueData,
      },
    });
  } catch (error) {
    next(error);
  }
};

// POST /api/v1/orders (Create Order - Enhanced with shipping)
export const createOrder = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction,
) => {
  try {
    const {
      items,
      shippingAddress,
      billingAddress,
      paymentMethod,
      shippingMethodId,
      discountCode,
      customerNotes,
    } = req.body;

    if (!req.user) throw new AppError("Authentication required", 401);
    const userId = req.user.userId;

    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user) throw new NotFoundError("User not found");

    // Validate shipping method
    const shippingMethod = await prisma.shippingMethod.findUnique({
      where: { id: shippingMethodId },
      include: { weightRates: true, zone: true },
    });
    if (!shippingMethod) throw new NotFoundError("Shipping method not found");

    let subtotal = 0;
    let totalWeight = 0;
    const orderItems: any[] = [];
    const categoryIds: string[] = [];
    const productIds: string[] = [];

    for (const item of items) {
      const product = await prisma.product.findUnique({
        where: { id: item.productId },
        include: { variations: true },
      });
      if (!product)
        throw new NotFoundError(`Product ${item.productId} not found`);
      if (product.status !== "ACTIVE")
        throw new AppError(`${product.name} is not available`, 400);

      if (item.variationId) {
        // ── Structured preset/variation (e.g. "500g Pack") ──────────────
        // Price and stock requirement always come from the server-side
        // variation record — never from client-supplied values — so a
        // stale price shown in an abandoned tab, or a tampered request,
        // can't under-charge or over-sell a preset.
        const variation = findActiveVariation(product as any, item.variationId);
        const packCount = item.quantity > 0 ? item.quantity : 1;
        const resolved = resolveVariationLine(variation, packCount);
        assertVariationStock(
          product as any,
          variation,
          resolved,
          product.allowBackorder,
        );

        subtotal += resolved.subtotal;
        totalWeight += (product.weight || 0) * resolved.baseQty;

        categoryIds.push(product.categoryId);
        productIds.push(product.id);

        orderItems.push({
          productId: product.id,
          productName: product.name,
          productSku: product.sku,
          productImage: product.images[0] || null,
          netWeight: product.netWeight || null,
          scaleUnit: product.scaleUnit || null,
          variationId: variation.id,
          variationLabel: variation.label,
          stockMode: resolved.stockMode,
          quantity: resolved.packCount,
          price: resolved.unitPrice,
          subtotal: resolved.subtotal,
        });
        continue;
      }

      // ── Legacy fixed / free-form custom-weight line (unchanged) ────────
      // For scalable products, stockQuantity and item.quantity are both in
      // scale units (e.g. kg). For fixed products, both are whole integers.
      if (!product.allowBackorder && product.stockQuantity < item.quantity) {
        const unit = product.isScalable ? product.scaleUnit || "unit" : "units";
        throw new AppError(
          `Insufficient stock for ${product.name} (available: ${product.stockQuantity} ${unit})`,
          400,
        );
      }

      // ── Price ──────────────────────────────────────────────────────────────
      // Scalable: price = pricePerUnit × quantity (quantity is float scale amount)
      // Fixed:    price = product.price × quantity
      const unitPrice =
        product.isScalable && product.pricePerUnit
          ? product.pricePerUnit
          : product.price;
      const itemSubtotal = unitPrice * item.quantity;
      subtotal += itemSubtotal;

      // Shipping weight:
      // product.weight = kg per 1 unit/scale-unit
      // × item.quantity = total kg for shipment
      totalWeight += (product.weight || 0) * item.quantity;

      categoryIds.push(product.categoryId);
      productIds.push(product.id);

      orderItems.push({
        productId: product.id,
        productName: product.name,
        productSku: product.sku,
        productImage: product.images[0] || null,
        netWeight: product.netWeight || null,
        scaleUnit: product.isScalable ? product.scaleUnit || null : null,
        quantity: item.quantity,
        price: unitPrice,
        subtotal: itemSubtotal,
      });
    }

    // Calculate shipping cost
    let shippingCost = 0;
    if (shippingMethod.type === "FLAT_RATE") {
      shippingCost = shippingMethod.flatRateCost || 0;
    } else if (shippingMethod.type === "TABLE_RATE") {
      const applicableRate = shippingMethod.weightRates.find(
        (rate) =>
          totalWeight >= rate.minWeight &&
          (rate.maxWeight === null || totalWeight <= rate.maxWeight),
      );
      shippingCost = applicableRate?.cost || 0;
    } else if (shippingMethod.type === "STORE_PICKUP") {
      shippingCost = 0;
    }

    // Apply discount
    let discountAmount = 0;
    let discountId: string | null = null;

    if (discountCode) {
      const discount = await prisma.discount.findFirst({
        where: { code: discountCode.toUpperCase(), isActive: true },
      });

      if (!discount) throw new AppError("Invalid discount code", 400);
      if (discount.endDate && discount.endDate < new Date())
        throw new AppError("Discount code has expired", 400);
      if (discount.usageLimit && discount.usageCount >= discount.usageLimit)
        throw new AppError("Discount code usage limit reached", 400);
      if (discount.minOrderAmount && subtotal < discount.minOrderAmount) {
        throw new AppError(
          `Minimum order amount of ₦${discount.minOrderAmount} required`,
          400,
        );
      }

      if (discount.type === "PERCENTAGE") {
        discountAmount = (subtotal * discount.value) / 100;
        if (discount.maxDiscount)
          discountAmount = Math.min(discountAmount, discount.maxDiscount);
      } else if (discount.type === "FIXED_AMOUNT") {
        discountAmount = Math.min(discount.value, subtotal);
      } else if (discount.type === "FREE_SHIPPING") {
        discountAmount = shippingCost;
      }

      discountId = discount.id;
    }

    const tax = 0;
    const total =
      subtotal -
      discountAmount +
      tax +
      (discountCode && discountAmount >= shippingCost ? 0 : shippingCost);

    // Estimate delivery date
    const estimatedDelivery = new Date();
    const maxDays = shippingMethod.estimatedMaxDays || 5;
    estimatedDelivery.setDate(estimatedDelivery.getDate() + maxDays);

    const order = await prisma.$transaction(
      async (tx) => {
        // ── CORE TRANSACTION: only writes that must roll back together ─────────
        // Every await is a network round-trip to MongoDB Atlas. Keep this lean.
        // Stock deduction is NOT here — it happens at payment confirmation only.

        const newOrder = await tx.order.create({
          data: {
            orderNumber: generateOrderNumber(),
            userId,
            status: "PENDING",
            subtotal,
            discountAmount,
            tax,
            shippingCost,
            total,
            paymentMethod,
            paymentStatus: "PENDING",
            shippingAddress,
            billingAddress: billingAddress || shippingAddress,
            shippingMethodId: shippingMethod.id,
            shippingMethodName: shippingMethod.name,
            estimatedDelivery,
            customerName: user.name,
            customerEmail: user.email,
            customerPhone: user.phone || shippingAddress.phone,
            discountCode: discountCode || null,
            discountId,
            customerNotes,
            items: { create: orderItems },
          },
          include: { items: true },
        });

        // Discount usage must be atomic with order creation
        if (discountId) {
          await tx.discount.update({
            where: { id: discountId },
            data: { usageCount: { increment: 1 } },
          });
        }

        // Clear cart — customer expects empty cart immediately
        const cart = await tx.cart.findFirst({ where: { userId } });
        if (cart) await tx.cartItem.deleteMany({ where: { cartId: cart.id } });

        return newOrder;
      },
      { timeout: 30000 }, // 30s — MongoDB Atlas + Nigeria latency needs more than 5s default
    );

    // ── POST-TRANSACTION: best-effort writes (run in parallel, don't block response) ──
    await Promise.allSettled([
      prisma.orderStatusHistory.create({
        data: { orderId: order.id, status: "PENDING", notes: "Order placed" },
      }),
      prisma.orderTrackingUpdate.create({
        data: {
          orderId: order.id,
          status: "Order Confirmed",
          message: "Your order has been received and is being processed",
          timestamp: new Date(),
        },
      }),
      prisma.user.update({
        where: { id: userId },
        data: {
          totalSpent: { increment: total },
          orderCount: { increment: 1 },
          lastOrderDate: new Date(),
        },
      }),
    ]);

    // Invoice/order-confirmation email — respects Settings → Notifications
    // → "Invoice email" mode (manual by default; staff sends it via the
    // "Send Invoice" button on the order unless a super admin turns auto on).
    maybeSendInvoiceEmail(order.id).catch((err) =>
      console.error("[email] Order confirmation failed:", err),
    );

    // Notify admin notification emails (configured in Settings → Notifications)
    prisma.siteSetting
      .findFirst()
      .then((cfg) => {
        const adminEmails: string[] =
          (cfg as any)?.adminNotificationEmails ?? [];
        if (adminEmails.length === 0) return;
        return sendAdminNewOrderEmail(
          adminEmails,
          order.orderNumber,
          user.name,
          user.email,
          total,
          order.items?.length ?? 0,
        );
      })
      .catch((err) =>
        console.error("[email] Admin order notification failed:", err),
      );

    logActivity({
      userId: (req as AuthRequest).user?.userId,
      action: "create order",
      entity: "order",
      entityId: order.id,
      metadata: { orderNumber: order.orderNumber, total: order.total },
      req,
    });

    res.status(201).json({
      success: true,
      message: "Order placed successfully",
      data: { order },
    });
  } catch (error) {
    next(error);
  }
};

// GET /api/v1/orders/:id/tracking
export const getOrderTracking = async (
  req: Request,
  res: Response,
  next: NextFunction,
) => {
  try {
    const id = req.params.id as string;

    const order = await prisma.order.findFirst({
      where: { OR: [{ id }, { orderNumber: id }] },
      select: {
        id: true,
        orderNumber: true,
        status: true,
        trackingNumber: true,
        trackingUrl: true,
        estimatedDelivery: true,
        deliveredAt: true,
        createdAt: true,
        shippedAt: true,
        trackingUpdates: { orderBy: { timestamp: "desc" } },
      },
    });

    if (!order) throw new NotFoundError("Order not found");

    res.status(200).json({ success: true, data: { order } });
  } catch (error) {
    next(error);
  }
};

// POST /api/v1/orders/:id/tracking
export const addTrackingUpdate = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction,
) => {
  try {
    const id = req.params.id as string;
    const { status, message, location } = req.body;

    const order = await prisma.order.findUnique({
      where: { id },
      include: { user: true },
    });
    if (!order) throw new NotFoundError("Order not found");

    const update = await prisma.orderTrackingUpdate.create({
      data: {
        orderId: order.id,
        status,
        message,
        location,
        timestamp: new Date(),
      },
    });

    // Customer tracking-event notification — respects Settings →
    // Notifications → "Order status email" mode (manual by default).
    const { orderStatusEmailMode } = await getEmailAutomationModes();
    if (orderStatusEmailMode === "auto") {
      sendTrackingUpdateEmail(
        order.user.email,
        order.user.name,
        order.orderNumber,
        status,
        message,
      )
        .then(() =>
          prisma.order.update({
            where: { id },
            data: { lastStatusEmailAt: new Date() },
          }),
        )
        .catch((err) =>
          console.error("[email] Tracking update email failed:", err),
        );
    }

    res.status(201).json({
      success: true,
      message: "Tracking update added",
      data: { update },
    });
  } catch (error) {
    next(error);
  }
};

// PUT /api/v1/orders/:id/tracking-number
export const updateTrackingNumber = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction,
) => {
  try {
    const id = req.params.id as string;
    const { trackingNumber, trackingUrl } = req.body;

    const order = await prisma.order.findUnique({ where: { id } });
    if (!order) throw new NotFoundError("Order not found");

    const updated = await prisma.order.update({
      where: { id },
      data: { trackingNumber, trackingUrl },
    });

    res.status(200).json({
      success: true,
      message: "Tracking number updated",
      data: { order: updated },
    });
  } catch (error) {
    next(error);
  }
};

// POST /api/v1/orders/:id/send-invoice
// Manual trigger for the order-confirmation/invoice email — used when
// Settings → Notifications → Invoice email mode is "manual" (the default).
// Staff-side only (see staffOrAdmin on the route); can be re-sent any time.
export const sendInvoiceManually = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction,
) => {
  try {
    const id = req.params.id as string;
    const order = await prisma.order.findUnique({ where: { id } });
    if (!order) throw new NotFoundError("Order not found");

    await sendOrderConfirmationEmail(
      order.customerEmail,
      order.customerName,
      order.orderNumber,
      order.total,
    );

    await prisma.order.update({
      where: { id },
      data: { invoiceEmailSent: true },
    });

    logActivity({
      userId: req.user?.userId,
      action: "send invoice email",
      entity: "order",
      entityId: id,
      metadata: { orderNumber: order.orderNumber },
      req,
    });

    res.status(200).json({
      success: true,
      message: `Invoice sent to ${order.customerEmail}`,
    });
  } catch (error) {
    next(error);
  }
};

// POST /api/v1/orders/:id/notify-status
// Manual trigger for the order-status-update email — used when
// Settings → Notifications → Order status email mode is "manual" (the
// default). Sends a notification for the order's CURRENT status.
// Staff-side only (see staffOrAdmin on the route).
export const notifyOrderStatus = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction,
) => {
  try {
    const id = req.params.id as string;
    const { notes } = req.body;
    const order = await prisma.order.findUnique({ where: { id } });
    if (!order) throw new NotFoundError("Order not found");

    await sendTrackingUpdateEmail(
      order.customerEmail,
      order.customerName,
      order.orderNumber,
      order.status,
      notes || `Your order status has been updated to ${order.status}.`,
    );

    await prisma.order.update({
      where: { id },
      data: { lastStatusEmailAt: new Date() },
    });

    logActivity({
      userId: req.user?.userId,
      action: "notify customer of order status",
      entity: "order",
      entityId: id,
      metadata: { orderNumber: order.orderNumber, status: order.status },
      req,
    });

    res.status(200).json({
      success: true,
      message: `Customer notified at ${order.customerEmail}`,
    });
  } catch (error) {
    next(error);
  }
};
